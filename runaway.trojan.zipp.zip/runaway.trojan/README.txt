  ______                                   
 |  ____|                                  
 | |__ ___ _________   _  ___ _   _ _   _  
 |  __/ _ \_  /_  / | | |/ _ \ | | | | | | 
 | | | (_) / / / /| |_| |  __/ |_| | |_| | 
 |_|  \___/___/___|\__, |\___|\__, |\__, | 
                    __/ |      __/ | __/ | 
                   |___/      |___/ |___/  

THIS MALWARE NOT A JOKE!

BEFORE LAUNCH, DOWNLOAD A PYTHON WITH PIP AND PATH
AND INSTALL A PYWIN32
How to install pywin32: after python install go in cmd and write "pip install pywin32" without "

AND BEFORE LAUNCH, MOVE THIS FOLDER (runaway.trojan) ON DESKTOP AND LAUNCH THIS MALWARE ONLY IN THIS FOLDER!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Im not responsible for any your computer damage!!!!!!!!!

Test this malware only on virtual box!!!!!!!!!!!!!!!!

Test this malware only in windows 10, of curse you can use newer versions of Windows but there will be a risk that there will be bugs

Password: run111
Credits: Fozzyeyy

GOODLUCK